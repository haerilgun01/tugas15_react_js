import React, { useEffect } from 'react';
import './Navbar.css'; 

function Navbar() {
  let title = " Hello Welcome To My Landing Page";

  useEffect(() => {
    const moveBackground = () => {
      const navbar = document.querySelector('.navbar');
      window.addEventListener('scroll', () => {
        const offset = window.pageYYOffset;
        navbar.style.backgroundPositionY = -offset * 0.5 + 'px'; 
      });
    };

    moveBackground();
  }, []);

  return (
    <div className="navbar">
      <div className="centered-content">
        <img className="profile-image" src="https://pps.whatsapp.net/v/t61.24694-24/394785055_1754800395034067_823950723764549442_n.jpg?ccb=11-4&oh=01_AdQDFcZmAHAWjTaetfowEg6pQqCm09W-YoiaVICd4jG5cg&oe=654AB76E&_hnc_sid=000000&_nc_cat=105" alt="Your Profile" />
        <h2>{title}</h2>
      </div>
    </div>
  );
}

export default Navbar;